package servlet;

import java.io.IOException;
import java.util.NoSuchElementException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Cart;
import service.BusinessService;

/**
 * ���¹�����
 * Servlet implementation class UpdateQuantityServlet
 */
@WebServlet("/UpdateQuantityServlet")
public class UpdateQuantityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public UpdateQuantityServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		
		String id = request.getParameter("bookid");
		String quantity = request.getParameter("quantity");
		
		//��ȡ��ǰ�û��Ĺ��ﳵ
		Cart cart = (Cart) request.getSession().getAttribute("cart");
		
		try {
			//���ø���idɾ�����ﳵ�������
			BusinessService businessService = new BusinessService();
			businessService.updateQuantity(id,cart,quantity);
			
			//���¹��ﳵ��ĳ����Ʒ���飩�󷵻ع��ﳵ����ʾҳ��
			request.getRequestDispatcher("listCart.jsp").forward(request, response);
		}catch(NoSuchElementException e) {
			request.setAttribute("message", "���Ĺ��ﳵ�ǿյ�");
			request.getRequestDispatcher("message.jsp").forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
			request.setAttribute("message", "ɾ���г������쳣�������������£�");
			request.getRequestDispatcher("message.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
